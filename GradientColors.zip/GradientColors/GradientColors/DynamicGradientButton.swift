//
//  DynamicGradientButton.swift
//  GradientColors
//
//  Created by mps on 16/06/21.
//

import UIKit

class DynamicGradientButton: UIButton {

    let gradient = CAGradientLayer()
    
    init(colors:[CGColor]) {
        super.init(frame: .zero)
        gradient.frame = bounds
        gradient.colors = colors
        layer.addSublayer(gradient)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradient.frame = bounds
    }
}
