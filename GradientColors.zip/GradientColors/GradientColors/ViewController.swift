//
//  ViewController.swift
//  GradientColors
//
//  Created by mps on 16/06/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Gradients"
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.bounds
        gradientLayer.colors = [
        
            UIColor.systemRed.cgColor,
            UIColor.systemBlue.cgColor,
            UIColor.systemPink.cgColor,
            UIColor.systemTeal.cgColor,
            UIColor.systemGreen.cgColor
    
        ]
        
        view.layer.addSublayer(gradientLayer)
        
        
       // Button gradient
        let button = GradientButton(frame: CGRect(x: 0, y: 0, width: 300, height: 70))
        view.addSubview(button)
        button.center = view.center
        button.setTitle("GradientButton", for: .normal)
        button.layer.cornerRadius = 10
        button.clipsToBounds = true
        
        
        // Button gradient chage everything this VC.
        let buttonGradient = DynamicGradientButton(colors: [UIColor.systemBlue.cgColor,UIColor.systemRed.cgColor])
        buttonGradient.frame = CGRect(x: 100, y: 200, width: 200, height: 60)
         view.addSubview(buttonGradient)
      //  buttonGradient.center = view.center
        buttonGradient.setTitle("DynamicGradientButton", for: .normal)
        buttonGradient.layer.cornerRadius = 10
        buttonGradient.clipsToBounds = true
    }


}

